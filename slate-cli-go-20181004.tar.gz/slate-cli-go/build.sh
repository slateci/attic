!#/bin/bash
GOPATH=`pwd`
export GOPATH
echo $GOPATH
go env GOPATH
go get github.com/slateci/slate-cli/slate
go install github.com/slateci/slate-cli/slate
