package helm

import (
	"os/exec"
	"os"
	"time"
	"strconv"
	"strings"
	"fmt"
	"github.com/slateci/slate-cli/util"
)

var _ = fmt.Printf

func HelmInit() {
	command := exec.Command("helm", "init")
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}

type HelmLsOutput struct {
	table util.StringTable
}



func (output *HelmLsOutput) Instances() []HelmInstance {
	instances := []HelmInstance{}
	for row := 0; row < output.table.RowCount(); row++ {
		instances = append(instances, HelmInstance{output, row})
	}
	return instances
}

func (this *HelmLsOutput) String() string {
	return this.table.String()
}

type HelmInstance struct {
	output *HelmLsOutput
	id int
}

func (this *HelmInstance) Name() string {
	return this.output.table.GetValue(this.id, 0)
}

func (this *HelmInstance) Revision() string {
	return this.output.table.GetValue(this.id, 1)
}

func (this *HelmInstance) Updated() string {
	return this.output.table.GetValue(this.id, 2)
}

func (this *HelmInstance) Status() string {
	return this.output.table.GetValue(this.id, 3)
}

func (this *HelmInstance) ChartName() string {
	chart := this.output.table.GetValue(this.id, 4)
	index := strings.LastIndex(chart, "-")
	return chart[: index]
}

func (this *HelmInstance) ChartVersion() string {
	chart := this.output.table.GetValue(this.id, 4)
	index := strings.LastIndex(chart, "-")
	return chart[index + 1: ]
}

func (this *HelmInstance) Namespace() string {
	return this.output.table.GetValue(this.id, 5)
}

func HelmLs() HelmLsOutput {
	out, err := exec.Command("helm", "ls").Output()
	if err != nil {
		panic(err)
	}
	text := string(out)
	lines := strings.Split(text, "\n")
	var output HelmLsOutput
	if (len(lines) < 2) {
	} else {
		output = HelmLsOutput{*util.ParseLines(lines[:len(lines) - 1])}
	}
	return output
}

func HelmRepoAddSlateDev() {
	command := exec.Command("helm", "repo", "add", "slate-dev", "https://raw.githubusercontent.com/slateci/slate-catalog/master/incubator-repo/")
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}

func HelmInstallDevApp(appname string) {

	command := exec.Command("helm", "install", "slate-dev/"+appname, "-n", appname+"-"+strconv.FormatInt(time.Now().Unix(), 10))
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}

func HelmDeleteAppInstance(instanceName string) {
	command := exec.Command("helm", "delete", instanceName)
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}
