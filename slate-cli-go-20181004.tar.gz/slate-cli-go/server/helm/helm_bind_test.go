package helm

import (
	"testing"
	"github.com/corbym/gocrest/then"
	"github.com/corbym/gocrest/is"
//	"github.com/corbym/gocrest/has"
	"github.com/slateci/slate-cli/util"
)

var helmLsOutput1 = `NAME                            REVISION        UPDATED                         STATUS          CHART                           NAMESPACE
osg-frontier-squid-1521040595   1               Wed Mar 14 11:16:36 2018        DEPLOYED        osg-frontier-squid-0.1.0        default`


func TestOutput(t *testing.T) {
	output := HelmLsOutput{*util.Parse(helmLsOutput1)}
	then.AssertThat(t, output.Instances()[0].Name(), is.EqualTo("osg-frontier-squid-1521040595"))
	then.AssertThat(t, output.Instances()[0].Revision(), is.EqualTo("1"))
	then.AssertThat(t, output.Instances()[0].Updated(), is.EqualTo("Wed Mar 14 11:16:36 2018"))
	then.AssertThat(t, output.Instances()[0].Status(), is.EqualTo("DEPLOYED"))
	then.AssertThat(t, output.Instances()[0].ChartName(), is.EqualTo("osg-frontier-squid"))
	then.AssertThat(t, output.Instances()[0].ChartVersion(), is.EqualTo("0.1.0"))
	then.AssertThat(t, output.Instances()[0].Namespace(), is.EqualTo("default"))
}