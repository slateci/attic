package kubectl

import (
	"fmt"
	"os/exec"
)

func Echo(text string) {
	fmt.Println(text)
}

func KubernetesGetPods() {
	command := exec.Command("kubectl", "get", "pods")
	cmdOut, err := command.Output()
	if err != nil {
		panic(err)
	}
	fmt.Println("Successfully run kubectl " + string(cmdOut))
}
