package main

import (
	"fmt"
	"encoding/json"
	"k8s.io/client-go/util/homedir"
	"io/ioutil"
	"os"
	"path"
)

type SlateDatabase struct {
	InstalledApps []InstalledApp
}

type InstalledApp struct {
	AppName string
	InstanceName string
}

func getDbLocation() string {
	return homedir.HomeDir() + "/.slate/db.yaml"
}

var database *SlateDatabase

func getDatabase() *SlateDatabase {
	if (database == nil) {
		if _, err := os.Stat(getDbLocation()); os.IsNotExist(err) {
			os.MkdirAll(path.Dir(getDbLocation()), 0644)
			database = &SlateDatabase{[]InstalledApp{}}
			saveDatabase()
		} else {
			raw, err := ioutil.ReadFile(getDbLocation())
			if err != nil {
				panic(err)
			}

			json.Unmarshal(raw, &database)
		}
	}
	return database
}

func saveDatabase() {
	rankingsJson, err := json.Marshal(getDatabase())
	if err != nil {
		panic(err)
	}
	err = ioutil.WriteFile(getDbLocation(), rankingsJson, 0644)
	if err != nil {
		fmt.Println(err)
	}
}

func AddInstalledApp(appName string, instanceName string) {
	getDatabase().InstalledApps = append(getDatabase().InstalledApps, InstalledApp{appName, instanceName})
	saveDatabase()
}
