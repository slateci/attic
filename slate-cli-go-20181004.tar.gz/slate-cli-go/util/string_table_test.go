package util

import (
	"testing"
	"github.com/corbym/gocrest/then"
	"github.com/corbym/gocrest/is"
//	"github.com/corbym/gocrest/has"
)

var helmLsOutput1 = `NAME                            REVISION        UPDATED                         STATUS          CHART                           NAMESPACE
osg-frontier-squid-1521040595   1               Wed Mar 14 11:16:36 2018        DEPLOYED        osg-frontier-squid-0.1.0        default`


func TestParse1(t *testing.T) {
	table := Parse(helmLsOutput1)
	then.AssertThat(t, table.GetTitle(0), is.EqualTo("NAME"))
	then.AssertThat(t, table.GetTitle(1), is.EqualTo("REVISION"))
	then.AssertThat(t, table.GetTitle(2), is.EqualTo("UPDATED"))
	then.AssertThat(t, table.GetTitle(3), is.EqualTo("STATUS"))
	then.AssertThat(t, table.GetTitle(4), is.EqualTo("CHART"))
	then.AssertThat(t, table.GetTitle(5), is.EqualTo("NAMESPACE"))
	then.AssertThat(t, table.GetValue(0,0), is.EqualTo("osg-frontier-squid-1521040595"))
	then.AssertThat(t, table.GetValue(0,1), is.EqualTo("1"))
	then.AssertThat(t, table.GetValue(0,2), is.EqualTo("Wed Mar 14 11:16:36 2018"))
	then.AssertThat(t, table.GetValue(0,3), is.EqualTo("DEPLOYED"))
	then.AssertThat(t, table.GetValue(0,4), is.EqualTo("osg-frontier-squid-0.1.0"))
	then.AssertThat(t, table.GetValue(0,5), is.EqualTo("default"))
}

func TestToString(t *testing.T) {
	table := StringTable{[]string{"A", "B", "C"}, [][]string{{"This", "is", "looooooooooong"}, {"But", "this is", "short"}}};
	formatted :=
`A    B       C             
This is      looooooooooong
But  this is short         `
	then.AssertThat(t, table.String(), is.EqualTo(formatted));

}