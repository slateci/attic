package util

import (
	"strings"
	"fmt"
	"unicode"
)

var _ = fmt.Printf

type StringTable struct {
	titles []string
	data [][]string
}

func (table *StringTable) ColumnCount() int {
	return len(table.titles)
}

func (table *StringTable) RowCount() int {
	return len(table.data)
}

func (table *StringTable) GetValue(row int, column int) string {
	return table.data[row][column]
}

func (table *StringTable) GetTitle(column int) string {
	return table.titles[column]
}

func Parse(text string) *StringTable {
	lines := strings.Split(text, "\n")
	return ParseLines(lines)
}

func ParseLines(lines []string) *StringTable {
	if (len(lines) != 0) {
		firstLine := lines[0]
		previousSpace := true
		boundaries := []int{}
		titles := []string{}
		for index, runeValue := range firstLine {
			currentSpace := unicode.IsSpace(runeValue)
			if (!currentSpace && previousSpace) {
				boundaries = append(boundaries, index)
			}
			previousSpace = currentSpace
		}
		column := 0
		for column =0; column < len(boundaries) - 1; column++ {
			titles = append(titles, strings.Trim(firstLine[boundaries[column]:boundaries[column+1]], " "))
		}
		titles = append(titles, strings.TrimSpace(firstLine[boundaries[column]:]))
		data := [][]string{}
		for row := 1; row < len(lines); row++ {
			rowData := []string{}
			column := 0
			for column = 0; column < len(boundaries) - 1; column++ {
				rowData = append(rowData, strings.TrimSpace(lines[row][boundaries[column]:boundaries[column+1]]))
			}
			rowData = append(rowData, strings.TrimSpace(lines[row][boundaries[column]:]))
			data = append(data, rowData)
		}
		return &StringTable{titles, data}
	} else {
		return &StringTable{[]string{}, [][]string{}}
	}
}

func (table *StringTable) String() string {
	maxColumnLength := make([]int, table.ColumnCount())
	for col := 0; col < table.ColumnCount(); col++  {
		maxColumnLength[col] = len(table.GetTitle(col))
		for row := 0; row < table.RowCount(); row ++ {
			maxColumnLength[col] = Max(maxColumnLength[col], len(table.GetValue(row, col)))
		}
	}
	var output strings.Builder;
	for col := 0; col < table.ColumnCount(); col ++ {
		if (col != 0) {
			output.WriteString(" ");
		}
		output.WriteString(padRight(table.GetTitle(col), " ", maxColumnLength[col],));
	}
	for row := 0; row < table.RowCount(); row ++ {
		output.WriteString("\n")
		for col := 0; col < table.ColumnCount(); col ++ {
			if (col != 0) {
				output.WriteString(" ");
			}
			output.WriteString(padRight(table.GetValue(row, col), " ", maxColumnLength[col],));
		}
	}
	return output.String();
}

func padRight(str, pad string, length int) string {
	for {
		str += pad
		if len(str) > length {
			return str[0:length]
		}
	}
}