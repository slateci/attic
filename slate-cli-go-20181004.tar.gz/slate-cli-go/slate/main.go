package main

import (
	"github.com/slateci/slate-cli/cmd"
	"github.com/spf13/cobra"
)

func main() {

	var cmdApp= &cobra.Command{
		Use:   "app",
		Short: "Manage SLATE application",
		Long: `Commands to manage SLATE applications.`,
	}

	var cmdAppInstall = &cobra.Command{
		Use:   "install [appname]",
		Short: "Install a SLATE application",
		Long: `install will fetch and install an application from the SLATE catalog.
The permission will be checked.`,
		Args: cobra.ExactArgs(1),
		Run:  cmd.Install,
	}

	var cmdAppList = &cobra.Command{
		Use:   "list",
		Short: "List installed SLATE applications",
		Long: `Lists all the installed SLATE applications`,
		Args: cobra.MinimumNArgs(0),
		Run: cmd.List,
	}

	var cmdAppDelete = &cobra.Command{
		Use:   "delete [appname]",
		Short: "Deletes a SLATE application",
		Long: `delete will uninstall a SLATE application and all its data.
The permission will be checked.`,
		Args: cobra.MinimumNArgs(1),
		Run: cmd.Delete,
	}
	cmdApp.AddCommand(cmdAppInstall, cmdAppList, cmdAppDelete)

	var cmdDev= &cobra.Command{
		Use:   "dev",
		Short: "Manage SLATE development",
		Long: `Commands to manage the SLATE development environment.`,
	}

	var cmdDevStart = &cobra.Command{
		Use:   "start",
		Short: "Starts the SLATE dev environment",
		Long: `Starts the slate development environment.`,
		Args: cobra.ExactArgs(0),
		Run:  cmd.DevStart,
	}

	var cmdDevDelete = &cobra.Command{
		Use:   "delete",
		Short: "Tears down the SLATE dev environment",
		Long: `Tears down the slate development environment.`,
		Args: cobra.ExactArgs(0),
		Run:  cmd.DevDelete,
	}
	cmdDev.AddCommand(cmdDevStart, cmdDevDelete)

	var rootCmd = &cobra.Command{Use: "slate"}
	rootCmd.AddCommand(cmdApp, cmdDev)
	rootCmd.Execute()
}
