package cmd

import (
	"github.com/spf13/cobra"
)

func DevDelete(cmd *cobra.Command, args []string) {
	MinikubeDelete()
}
