package cmd

import (
	"github.com/spf13/cobra"
	"github.com/slateci/slate-cli/server/helm"
)

func DevStart(cmd *cobra.Command, args []string) {
	MinikubeStart()
	helm.HelmInit()
	helm.HelmRepoAddSlateDev()
}
