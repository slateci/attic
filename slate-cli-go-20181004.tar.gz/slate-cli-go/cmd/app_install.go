package cmd

import (
	"github.com/slateci/slate-cli/server/helm"
	"github.com/spf13/cobra"
)

func Install(cmd *cobra.Command, args []string) {
	helm.HelmInstallDevApp(args[0])
}
