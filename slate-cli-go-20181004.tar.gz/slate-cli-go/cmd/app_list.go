package cmd

import (
	"github.com/spf13/cobra"
	"github.com/slateci/slate-cli/server/helm"
	"fmt"
)

func List(cmd *cobra.Command, args []string) {
	output := helm.HelmLs()
	fmt.Println(output.String())
}
