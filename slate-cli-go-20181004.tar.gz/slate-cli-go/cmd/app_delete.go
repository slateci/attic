package cmd

import (
	"github.com/spf13/cobra"
	"github.com/slateci/slate-cli/server/helm"
)

func Delete(cmd *cobra.Command, args []string) {
	appToDelete := args[0]
	output := helm.HelmLs()
	instancesToDelete := []helm.HelmInstance{}
	for row :=0; row < len(output.Instances()); row++ {
		if (output.Instances()[row].ChartName() == appToDelete) {
			instancesToDelete = append(instancesToDelete, output.Instances()[row])
		}
	}
	for row :=0; row < len(instancesToDelete); row++ {
		helm.HelmDeleteAppInstance(instancesToDelete[row].Name())
	}
}
