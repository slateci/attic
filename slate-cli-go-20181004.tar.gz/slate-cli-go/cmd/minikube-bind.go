package cmd

import (
	"fmt"
	"os/exec"
	"os"
)

func MinikubeStart() {
	fmt.Println("Starting minikube:")
	command := exec.Command("minikube", "start")
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}

func MinikubeDelete() {
	fmt.Println("Deleting minikube:")
	command := exec.Command("minikube", "delete")
	command.Stdout = os.Stdout
	command.Stderr = os.Stderr
	command.Run()
}
