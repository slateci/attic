# slate-cli

To build the command-line, do the following in an empty directory:

```
> wget https://raw.githubusercontent.com/slateci/slate-cli/master/build.sh
> chmod +x build.sh 
> ./build.sh 
```
