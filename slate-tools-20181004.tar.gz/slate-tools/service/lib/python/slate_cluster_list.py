import sys, json, subprocess;

result = subprocess.run(['kubectl', '--kubeconfig', '/usr/lib/slate-service/etc/kubeconfig', 'config', 'get-clusters'], stdout=subprocess.PIPE)
data = result.stdout.decode('utf-8')

output = {}
output['apiVersion'] = "v1alpha1"
output['items'] = []

for item in data.split()[1:]:
  cluster = {}
  cluster['apiVersion'] = "v1alpha1"
  cluster['kind'] = "Cluster"
  cluster['metadata'] = {}
  cluster['metadata']['name'] = item
  output['items'].append(cluster)
    
print(json.dumps(output))
