import sys, json, subprocess;

result = subprocess.run(['kubectl', '--kubeconfig', '/usr/lib/slate-service/etc/kubeconfig', 'get', 'namespaces', '--output=json'], stdout=subprocess.PIPE)
data = json.loads(result.stdout.decode('utf-8'))
#data = json.loads('{"key1" : "value1"}')
output = {}
output['apiVersion'] = "v1alpha1"
output['items'] = []

for item in data['items']:
  if item['metadata']['name'].startswith('vo-'):
    vo = {}
    vo['apiVersion'] = "v1alpha1"
    vo['kind'] = "Vo"
    vo['metadata'] = {}
    vo['metadata']['name'] = item['metadata']['name'][3:]
    output['items'].append(vo)
    
print(json.dumps(output))
