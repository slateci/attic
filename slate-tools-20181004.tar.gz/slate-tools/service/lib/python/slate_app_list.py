import sys, json, subprocess, os;

def parseLine(line, columnStart):
    tokens = []
    for col in range(0, len(columnStart)-1):
        tokens.append(line[columnStart[col]:columnStart[col+1]].strip())
    return tokens

data = json.loads(sys.stdin.read())
if 'cluster' not in data:
    print(json.dumps({'kind': "Error", 'message': "Missing cluster options"}))
    exit(-1)
           
env = os.environ.copy()
env["KUBECONFIG"] = "/usr/lib/slate-service/etc/kubeconfig"
cluster = data['cluster']
result = subprocess.run(['helm', 'list', '--kube-context', cluster], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
data = result.stdout.decode('utf-8')
lines = data.splitlines()
errorLines = result.stderr.decode('utf-8').splitlines()

# Check whether we have an error
if errorLines and errorLines[0].startswith("Error:"):
    print(json.dumps({'kind': "Error", 'message': errorLines[0][7:]}))
    exit(-1)

# Return if no table
if not lines:
    print (json.dumps({'apiVersion': "v1alpha1", 'items': []}))
    exit(0)

columnStart = []
whiteSpace = True
position = 0
for ch in lines[0]:
    if ch.isspace():
        whiteSpace = True
    else:
        if whiteSpace == True:
            columnStart.append(position)
            whiteSpace = False
        whiteSpace = False
    position += 1
columnStart.append(len(lines[0]))

output = {}
output['apiVersion'] = "v1alpha1"
output['items'] = []

for line in lines[1:]:
    tokens = parseLine(line, columnStart)
    if tokens[5].startswith("vo-"):
        app = {'apiVersion' : "v1alpha1",
               'kind' : "ApplicationInstance",
               'metadata' : {
                   'name' : tokens[0],
                   'revision' : tokens[1],
                   'updated' : tokens[2],
                   'application' : tokens[4],
                   'vo' : tokens[5][3:]
               },
               'status' : {
                   'phase' : tokens[3]
               }}
        output['items'].append(app)
print(json.dumps(output))
