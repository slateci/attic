import sys, json, subprocess, os;

request = json.loads(sys.stdin.read())
if 'applicationInstances' not in request:
    print(json.dumps({'kind': "Error", 'message': "Missing applicationInstances option"}))
    exit(-1)

env = os.environ.copy()
env["KUBECONFIG"] = "/usr/lib/slate-service/etc/kubeconfig"
application_instance_names = request['applicationInstances']
cluster_name = request['cluster']
command = ['helm', 'delete']
command += application_instance_names
command.append('--kube-context')
command.append(cluster_name)
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
data = result.stdout.decode('utf-8')
lines = data.splitlines()
errorLines = result.stderr.decode('utf-8').splitlines()

# Check whether we have an error
if errorLines and errorLines[0].startswith("Error:"):
    print(json.dumps({'kind': "Error", 'message': errorLines[0][7:]}))
    exit(-1)        

print(json.dumps({}))
