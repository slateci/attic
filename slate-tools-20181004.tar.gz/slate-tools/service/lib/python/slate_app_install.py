import time, sys, json, subprocess, os;

request = json.loads(sys.stdin.read())
if 'application' not in request:
    print(json.dumps({'kind': "Error", 'message': "Missing application option"}))
    exit(-1)
if 'cluster' not in request:
    print(json.dumps({'kind': "Error", 'message': "Missing cluster option"}))
    exit(-1)
if 'vo' not in request:
    print(json.dumps({'kind': "Error", 'message': "Missing vo option"}))
    exit(-1)

env = os.environ.copy()
env["KUBECONFIG"] = "/usr/lib/slate-service/etc/kubeconfig"
application_name = request['application']
cluster_name = request['cluster']
vo_name = request['vo']
application_instance_name = request['application'] + "-" + str(int(time.time()))
result = subprocess.run(['helm', 'install', 'slate-dev/' + application_name,
                         '--kube-context', cluster_name,
                         '--name', application_instance_name,
                         '--namespace', 'vo-' + vo_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
data = result.stdout.decode('utf-8')
err = result.stderr.decode('utf-8')
errorLines = err.splitlines()

# Check whether we have an error
if errorLines:
    if errorLines[0].startswith("Error: failed to download"):
        print(json.dumps({'kind': "Error", 'message': "Couldn't find or download application \"" + application_name + "\"" }))
        exit(-1)
    if errorLines[0].startswith("Error:"):
        print(json.dumps({'kind': "Error", 'message': errorLines[0][7:]}))
        exit(-1)
                

lines = data.splitlines()

if len(lines) > 0:
    if lines[0].startswith("NAME: "):
        print(json.dumps({'apiVersion': "v1alpha1",
                          'kind': "ApplicationInstance",
                          "metadata": {"application": application_name, "vo": vo_name, "updated": "TODO", "name": application_instance_name, "revision": "1"},
                          'status': {"phase": "DEPLOYED"}}))
        exit(0)
                            

print(json.dumps({'kind': "Error", 'message': "Unexpected response.\nstdout\n" + data + "\nstderr\n" + err}))
