#!/bin/bash
sudo rm -rf /usr/lib/slate-service/lib
sudo cp -r build/target/slate-service /usr/lib
