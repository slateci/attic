#!/bin/bash
rm -rf build
mkdir -p build/target/slate-service
cp -r service/lib build/target/slate-service

cd build
mkdir cli
cd cli
cmake ../../cli
make
cp slate ../target
cd ../..

