# SLATE command-line manual

This document contains the full user documentation and developer guide for the SLATE command-line interface. It is
stored in github so that it is kept in synch with the development. To refer to the documentation for your particular
version, please refer to the corresponding tag.

## Table of Contents

1. [General tips](#general-tips)
   1. [--help](#--help)
   1. [--output](#--output)
1. [slate cluster commands](#slate-cluster-commands)
   1. [slate cluster list](#slate-cluster-list)
1. [slate vo commands](#slate-vo-commands)
   1. [slate vo create](#slate-vo-create)
   1. [slate vo list](#slate-vo-list)
   1. [slate vo delete](#slate-vo-delete)
1. [slate app commands](#slate-app-commands)
   1. [slate app search](#slate-app-search)
   1. [slate app conf](#slate-app-conf)
   1. [slate app install](#slate-app-install)
   1. [slate app list](#slate-app-list)
   1. [slate app delete](#slate-app-delete)

## General tips

Like many other command line tools (e.g. git, mercurial, ...), the slate command-line consists of a series of
commands and subcommands. Flags and options can be combined (e.g. ``slate -a -b`` or ``slate -ab``). Option values can
follow a space or an equal (e.g. ``slate --output json`` or ``slate --output=json``). Some options have both a short and
a long form (e.g. ``slate -h`` or ``slate --help``).

### --help

A help message can be generated for each command and subcommand.

Examples:

```
> slate --help
SLATE command line interface
Usage: ./slate [OPTIONS] SUBCOMMAND

Options:
  -h,--help                   Print this help message and exit

General:
  --output TEXT               Output format. Must be default or json.
  --debug                     Prints extra info to debug the commandline.

Subcommands:
  app                         Manage SLATE applications
  version                     Outputs the version of the command-line
  vo                          Manage SLATE vos
  cluster                     Manage SLATE clusters
```
```
> slate app --help
Manage SLATE applications
Usage: ./slate app [OPTIONS] SUBCOMMAND

Options:
  -h,--help                   Print this help message and exit
  --vo TEXT (REQUIRED)        The VO for which to install the application
  --cluster TEXT (REQUIRED)   The cluster in which to install the application

Subcommands:
  install                     Install an application
  list                        Lists installed applications
  delete                      Delete an application

```

KNOWN ISSUES: the options that are common to more than one subcommand are only printed for the top-most command.

### --output

By default, the command-line formats the output for human interaction (i.e. compat format, data in tables, simple error
reporting). For most commands, one can ask the result to be formatted in JSON, so that it can be more easily consumed
by scripts.

Examples:
```
> slate vo list
NAME 
atlas
```
```
> slate vo list --output json
{
    "apiVersion": "v1alpha1",
    "items": [
        {
            "apiVersion": "v1alpha1",
            "kind": "Vo",
            "metadata": {
                "name": "atlas"
            }
        }
    ]
}
```

NOTE: the JSON format is not currently finalized and serves as an example.

NOTE: the JSON format will match the output of the services once it is implemented, making it easier to port application
built around the command-line to the REST API.


## slate vo commands

These commands allow the user to create/list/delete vos on the slate platform.

### slate vo create

Creates a new vo.

Examples:
```
carcassi@bunt4:~$ sudo slate vo create myvo
[sudo] password for carcassi:
NAME
myvo
```

NOTE: until proper user authentication and authorization is added, you may have to run the command as root.

### slate vo list

Lists the currently available vos.

Examples:
```
> slate vo list
NAME 
atlas
```
```
> slate vo list --output json
{
    "apiVersion": "v1alpha1",
    "items": [
        {
            "apiVersion": "v1alpha1",
            "kind": "Vo",
            "metadata": {
                "name": "atlas"
            }
        }
    ]
}
```

### slate vo delete

Deletes an existing vo.

Examples:
```
carcassi@bunt4:~$ sudo slate vo delete myvo
NAME
myvo
```

NOTE: until proper user authentication and authorization is added, you may have to run the command as root.
NOTE: currently the command does not check whether applications are currently installed within the vo to delete.


## slate cluster commands

These commands allow the user to manage the clusters available on the slate platform.

### slate cluster list

List the currently available clusters.

Examples:
```
> slate cluster list
NAME          
utah-bunt     
utah-coreos   
chicago-coreos
```
```
> slate cluster list --output json
{
    "apiVersion": "v1alpha1",
    "items": [
        {
            "apiVersion": "v1alpha1",
            "kind": "Cluster",
            "metadata": {
                "name": "chicago-coreos"
            }
        },
        {
            "apiVersion": "v1alpha1",
            "kind": "Cluster",
            "metadata": {
                "name": "utah-bunt"
            }
        },
        {
            "apiVersion": "v1alpha1",
            "kind": "Cluster",
            "metadata": {
                "name": "utah-coreos"
            }
        }
    ]
}

```


## slate app commands

These command allow the user to install/list/delete SLATE applications. For all these subcommands, one has to specify
the VO (i.e. ``--vo voname``) and cluster (i.e. ``--cluster clustername``). For search/conf/install 
the flag ``--dev`` uses the development versions instead of the stable ones.

### slate app search

Lists the applications available to be installed on the given cluster for the given vo.

Examples:
```
> slate app --vo atlas --cluster utah-bunt search
NAME                VERSION    DESCRIPTION                                       
jupyterhub          v0.7-dev   Multi-user Jupyter installation                   
osg-frontier-squid  0.2.0      A Helm chart for configuration and deployment o...
perfsonar           0.1.0      A Helm chart for Kubernetes
```

NOTE: given that each cluster and vo may limit what a use can or cannot install,
this command will need the vo and cluster options.

### slate app conf

Downloads the default configuration file for the application. By default, the
configuration file is saved in the current directory with the name ``appname.yaml``.
Alternatively, one can use the option ``--conf-file`` to specify the output.

Examples:
```
> slate app --vo atlas --cluster utah-bunt conf osg-frontier-squid --dev
> cat osg-frontier-squid.yaml
# Tag to label use case of Frontier Squid deployment
# Generates app name as "osg-frontier-squid-[Tag]"
# Enables unique instances of Frontier Squid in one namespace
Tag: global

Service:
  # Port that the service is utilizing within kubernetes cluster.
  Port: 3128
  # Use Type "NodePort" if you want the service to be accessible only within the cluster.
  # use type "LoadBalancer" if you want the service to also be accessible externally.
  Type: LoadBalancer

SquidConf:
  # The amount of memory (in MB) that Frontier Squid may use on the machine.
  # Per Frontier Squid, do not consume more than 1/8 of system memory with Frontier Squid
  CacheMem: 128
  # The amount of disk space (in MB) that Frontier Squid may use on the machine.
  # The default is 10000 MB (10 GB), but more is advisable if the system supports it.
  CacheSize: 10000

```

### slate app install

Installs a slate application on a particular cluster for a particular vo from the [slate
catalog](https://github.com/slateci/slate-catalog). The command will look in the current
directory for a file named ``appname.yaml`` and will use that as the configuration.
Alterinatively, the option ``--conf-file`` can be used to specify the configuration
file. If no configuration file is provided, the default one is used.

Examples:
```
> slate app --vo atlas --cluster utah-bunt install osg-frontier-squid
NAME                           APPLICATION         STATUS    UPDATED    VO   
osg-frontier-squid-1526913549  osg-frontier-squid  DEPLOYED  TODO       atlas
```

### slate app list

Lists the applications installed on a particular cluster for a particular vo.

Examples:
```
carcassi@ub1604dev:~/Development/slate-tools/cli/cmake-build-debug$ ./slate app --vo atlas --cluster utah-bunt list
NAME                           APPLICATION               STATUS    UPDATED                   VO   
osg-frontier-squid-1526575808  osg-frontier-squid-0.1.0  DEPLOYED  Thu May 17 12:50:08 2018  atlas
```

### slate app delete

Removes a particular running instance of a SLATE application.

Examples:
```
> slate app --vo atlas --cluster utah-bunt list
NAME                           APPLICATION               STATUS    UPDATED                   VO   
osg-frontier-squid-1526913549  osg-frontier-squid-0.1.0  DEPLOYED  Mon May 21 10:39:19 2018  atlas
> slate app --vo atlas --cluster utah-bunt delete osg-frontier-squid-1526913549
> slate app --vo atlas --cluster utah-bunt list
NAME                  APPLICATION  STATUS    UPDATED    VO   
```

