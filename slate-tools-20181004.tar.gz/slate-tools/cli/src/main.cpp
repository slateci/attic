#include "CLI11.h"
#include "Client.h"

using namespace std;
using namespace CLI;
using json = nlohmann::json;

const string SLATE_CLI_VERSION = "18.06";

inline string cliDocLink() {
    return "https://github.com/slateci/slate-tools/blob/" + SLATE_CLI_VERSION + "/cli/docs/manual.md";
}

struct GeneralOptions {
  string output;
  bool debug;
  Client client;
};

struct AppOptions {
  string vo;
  string cluster;
};

struct AppConfOptions {
    string application_name;
    string output_file;
    bool dev;
};

struct AppInstallOptions {
    string application_name;
    string conf;
    bool dev;
};

struct AppSearchOptions {
    bool dev;
};

struct AppListOptions {

};

struct AppDeleteOptions {
  vector<string> app_names;
};

struct VoOptions {
};

struct VoCreateOptions {
    string vo_name;
};

struct VoListOptions {
};

struct VoDeleteOptions {
    string vo_name;
};

struct ClusterOptions {
};

struct ClusterListOptions {
};

void formatTableRow(ostream& out, const vector<unsigned int>& columnWidth, const vector<string>& values) {
  for (unsigned int col = 0; col < columnWidth.size(); col++) {
    unsigned int valueSize = values[col].size();
    if (valueSize < columnWidth[col]) {
      string spaces(columnWidth[col] - valueSize, ' ');
      out << values[col] << spaces;
    } else {
      out << values[col].substr(0, columnWidth[col]);
    }
  }
  out << endl;
}

void formatTable(ostream& out, vector<unsigned int>& columnWidths, vector<string>& columnNames, vector<vector<string>>& rowValues) {
  formatTableRow(out, columnWidths, columnNames);
  for (unsigned int row = 0; row < rowValues.size(); row++) {
    formatTableRow(out, columnWidths, rowValues[row]);
  }
}

void formatJSONTable(ostream& out, vector<string>& columnNames, vector<json::json_pointer> pointers, vector<unsigned int> minColumnWidths, json& data) {
  vector<unsigned int> columnWidths = minColumnWidths;
  vector<vector<string>> values;
  for (unsigned int row = 0; row < data.size(); row++) {
    vector<string> rowValues;
    for (unsigned int col = 0; col < pointers.size(); col++) {
      string value = data[row][pointers[col]];
      rowValues.push_back(value);
      if (value.size() > columnWidths[col]) {
	columnWidths[col] = value.size();
      }
    }
    values.push_back(rowValues);
  }

  for (unsigned int col = 0; col < columnWidths.size() - 1; col++) {
    columnWidths[col] += 2;
  }

  formatTable(out, columnWidths, columnNames, values);
}

void printApplicationTable(ostream& out, json& data) {
    vector<string> columnNames = {"NAME", "VERSION", "DESCRIPTION"};
    vector<json::json_pointer> pointers = {"/metadata/name"_json_pointer,
                                           "/metadata/version"_json_pointer,
                                           "/metadata/description"_json_pointer};
    vector<unsigned int> minColumnWidths= {7, 9, 15};
    formatJSONTable(out, columnNames, pointers, minColumnWidths, data);
}

void printApplicationInstanceTable(ostream& out, json& data) {
    vector<string> columnNames = {"NAME", "APPLICATION", "STATUS", "UPDATED", "VO"};
    vector<json::json_pointer> pointers = {"/metadata/name"_json_pointer,
                                           "/metadata/application"_json_pointer,
                                           "/status/phase"_json_pointer,
                                           "/metadata/updated"_json_pointer,
                                           "/metadata/vo"_json_pointer};
    vector<unsigned int> minColumnWidths= {20, 11, 8, 9, 5};
    formatJSONTable(out, columnNames, pointers, minColumnWidths, data);
}

void printVoTable(ostream& out, json& data) {
    vector<string> columnNames = {"NAME"};
    vector<json::json_pointer> pointers = {"/metadata/name"_json_pointer};
    vector<unsigned int> minColumnWidths= {5};
    formatJSONTable(out, columnNames, pointers, minColumnWidths, data);
}

void printClusterTable(ostream& out, json& data) {
    vector<string> columnNames = {"NAME"};
    vector<json::json_pointer> pointers = {"/metadata/name"_json_pointer};
    vector<unsigned int> minColumnWidths= {5};
    formatJSONTable(out, columnNames, pointers, minColumnWidths, data);
}

bool isError(json& response) {
  return response["kind"] == "Error";
}

void printError(ostream& out, json& response) {
  string message = response["message"];
  out << "Error: " << message << endl;
}

void printResponse(GeneralOptions &genOpt, json& response, function<void(ostream&, json&)> formatter) {
  if (genOpt.debug) {
    cout << "printResponse" << response << endl;
  }
  
  if (genOpt.output == "json") {
    cout << response.dump(4) << endl;
  } else {
    if (isError(response)) {
      printError(cout, response);
    } else {
      formatter(cout, response);
    }
  }
}

void app_search(GeneralOptions &gen_opt, AppOptions &app_opt, AppSearchOptions &app_search_opt) {
    json request = {{"cluster", app_opt.cluster}, {"vo", app_opt.vo}};
    if (app_search_opt.dev) {
        request["developmentVersion"] = true;
    }
    json response = gen_opt.client.app_search(request);

    printResponse(gen_opt, response, [](ostream& out, json& response) -> void{
        printApplicationTable(cout, response["/items"_json_pointer]);
    });
}

void register_app_search(App *parent, GeneralOptions *gen_opt, AppOptions *app_opt) {
    auto app_search_opt = new AppSearchOptions();
    App *search = parent->add_subcommand("search", "Retrieves the list available applications in the catalog");
    search->add_flag("--dev", app_search_opt->dev, "Use the development version of the catalog");
    search->set_callback([gen_opt, app_opt, app_search_opt]() {app_search(*gen_opt, *app_opt, *app_search_opt);});
}

void app_conf(GeneralOptions &gen_opt, AppOptions &app_opt, AppConfOptions &app_conf_opt) {
    json request = {{"application", app_conf_opt.application_name}};
    if (app_conf_opt.dev) {
        request["developmentVersion"] = true;
    }
    json response = gen_opt.client.app_conf(request);

    string output_filename;
    if (app_conf_opt.output_file == "") {
        output_filename = app_conf_opt.application_name + ".yaml";
    } else {
        output_filename = app_conf_opt.output_file;
    }

    if (gen_opt.output != "json") {
        struct stat info;
        if (stat(output_filename.c_str(), &info) == 0) {
            cout << "File " + output_filename + " already exists" << endl;
            exit(-1);
        }
    }

    printResponse(gen_opt, response, [output_filename](ostream& out, json& response) -> void{
        string body = response["/spec/body"_json_pointer];
        std::ofstream output(output_filename);
        if (output) {
            output << body;
        }
    });
}

void register_app_conf(App *parent, GeneralOptions *gen_opt, AppOptions *app_opt) {
    auto app_conf_opt = new AppConfOptions();
    App *conf = parent->add_subcommand("conf", "Retrieves the configuration for an application");
    conf->add_option("app-name", app_conf_opt->application_name, "Application to configure")->required();
    conf->add_option("--conf-file", app_conf_opt->output_file, "The file where to save the default configuration");
    conf->add_flag("--dev", app_conf_opt->dev, "Use the development version of the application");
    conf->set_callback([gen_opt, app_opt, app_conf_opt]() {app_conf(*gen_opt, *app_opt, *app_conf_opt);});
}

void app_install(GeneralOptions &genOpt, AppOptions &appOpt, AppInstallOptions &appInstOpt) {

    string configuration;
    bool conf_given;
    bool conf_to_read = true;
    if (appInstOpt.conf == "") {
        conf_given = false;
        appInstOpt.conf = appInstOpt.application_name + ".yaml";
    } else {
        conf_given = true;
    }

    struct stat info;
    if (stat(appInstOpt.conf.c_str(), &info) != 0) {
        if (conf_given) {
            cout << "File " + appInstOpt.conf + " does not exist" << endl;
            exit(-1);
        } else {
            conf_to_read = false;
        }
    }

    if (conf_to_read) {
        std::ifstream conf_stream(appInstOpt.conf);
        if (conf_stream) {
            std::ostringstream contents;
            contents << conf_stream.rdbuf();
            conf_stream.close();
            configuration = contents.str();
        } else {
            cout << "Couldn't read " + appInstOpt.conf << endl;
            exit(-1);
        }
    }

    json request = {{"application", appInstOpt.application_name}, {"cluster", appOpt.cluster}, {"vo", appOpt.vo}};
    if (appInstOpt.dev) {
        request["developmentVersion"] = true;
    }
    if (conf_to_read) {
        request["configuration"] = configuration;
    }
    json response = genOpt.client.app_install(request);

    printResponse(genOpt, response, [](ostream& out, json& response) -> void{
        json array = {response};
        printApplicationInstanceTable(cout, array);
    });
}

void register_app_install(App *parent, GeneralOptions *genOpt, AppOptions *appOpt) {
    auto appInstOpt = new AppInstallOptions();
    App *install = parent->add_subcommand("install", "Install an application");
    install->add_option("app-names", appInstOpt->application_name, "Applications to install")->required();
    install->add_option("--conf-file", appInstOpt->conf, "The configuration file for the application");
    install->add_flag("--dev", appInstOpt->dev, "Use the development version of the application");
    install->set_callback([genOpt, appOpt, appInstOpt]() {app_install(*genOpt, *appOpt, *appInstOpt);});
}

void app_list(GeneralOptions &genOpt, AppOptions &appOpt, AppListOptions &appListOpt) {
  json request = {{"cluster", appOpt.cluster}, {"vo", appOpt.vo}};
  json response = genOpt.client.app_list(request);

  printResponse(genOpt, response, [](ostream& out, json& response) -> void{
      printApplicationInstanceTable(cout, response["/items"_json_pointer]);
    });
}

void register_app_list(App *parent, GeneralOptions *genOpt, AppOptions *appOpt) {
  auto appListOpt = new AppListOptions();
  App *list = parent->add_subcommand("list", "Lists installed applications");
  list->set_callback([genOpt, appOpt, appListOpt]() {app_list(*genOpt, *appOpt, *appListOpt);});    
}

void app_delete(GeneralOptions &genOpt, AppOptions &appOpt, AppDeleteOptions &appDelOpt) {
  json request = {{"applicationInstances", appDelOpt.app_names}, {"cluster", appOpt.cluster}, {"vo", appOpt.vo}};
  json response = genOpt.client.app_delete(request);

  printResponse(genOpt, response, [](ostream& out, json& response) -> void{
      // Do nothing;
    });
}

void register_app_delete(App *parent, GeneralOptions *genOpt, AppOptions *appOpt) {
  auto appDelOpt = new AppDeleteOptions();
  App *delete_ = parent->add_subcommand("delete", "Delete an application");
  delete_->add_option("app-names", appDelOpt->app_names, "Applications to install")->required();
  delete_->set_callback([genOpt, appOpt, appDelOpt]() {app_delete(*genOpt, *appOpt, *appDelOpt);});
}

void register_app(App *parent, GeneralOptions *genOpt) {
    auto appOpt = new AppOptions();
    App *app = parent->add_subcommand("app", "Manage SLATE applications");
    app->require_subcommand();
    app->add_option("--vo", appOpt->vo, "The VO for which to install the application")->required();
    app->add_option("--cluster", appOpt->cluster, "The cluster in which to install the application")->required();
    register_app_search(app, genOpt, appOpt);
    register_app_conf(app, genOpt, appOpt);
    register_app_install(app, genOpt, appOpt);
    register_app_list(app, genOpt, appOpt);
    register_app_delete(app, genOpt, appOpt);
}

void version(GeneralOptions &genOpt) {
  cout << "SLATE CLI version " << SLATE_CLI_VERSION << endl;
  cout << "Documentation at " << cliDocLink() << endl;
}

void register_version(App *parent, GeneralOptions *genOpt) {
  App *versionCmd = parent->add_subcommand("version", "Outputs the version of the command-line");
  versionCmd->set_callback([genOpt]() { version(*genOpt);});
}

void vo_create(GeneralOptions &genOpt, VoOptions &voOpt, VoCreateOptions &voCreateOpt) {
    json new_vo = {{"apiVersion", "v1alpha1"}, {"kind", "Vo"}, {"metadata", {{"name", voCreateOpt.vo_name}}}};

    json response = genOpt.client.vo_create(new_vo);

    printResponse(genOpt, response, [](ostream& out, json& response) -> void{
        json array;
        array.push_back(response);
        printVoTable(cout, array);
    });
}

void register_vo_create(App *parent, GeneralOptions *genOpt, VoOptions *voOpt) {
    auto voCreateOpt = new VoCreateOptions();
    App *create = parent->add_subcommand("create", "Create a new vo");
    create->add_option("vo-name", voCreateOpt->vo_name, "Name of the vo to create")->required();
    create->set_callback([genOpt, voOpt, voCreateOpt]() {vo_create(*genOpt, *voOpt, *voCreateOpt);});
}

void vo_list(GeneralOptions &genOpt, VoOptions &voOpt, VoListOptions &voListOpt) {
    json null;
    json response = genOpt.client.vo_list(null);

    printResponse(genOpt, response, [](ostream& out, json& response) -> void{
        printVoTable(cout, response["/items"_json_pointer]);
    });
}

void register_vo_list(App *parent, GeneralOptions *genOpt, VoOptions *voOpt) {
  auto voListOpt = new VoListOptions();
  App *list = parent->add_subcommand("list", "Lists available vos");
  list->set_callback([genOpt, voOpt, voListOpt]() {vo_list(*genOpt, *voOpt, *voListOpt);});
}

void vo_delete(GeneralOptions &genOpt, VoOptions &voOpt, VoDeleteOptions &voDeleteOpt) {
    json target_vo = {{"apiVersion", "v1alpha1"}, {"kind", "Vo"}, {"metadata", {{"name", voDeleteOpt.vo_name}}}};

    json response = genOpt.client.vo_delete(target_vo);

    printResponse(genOpt, response, [](ostream& out, json& response) -> void{
        json array;
        array.push_back(response);
        printVoTable(cout, array);
    });
}

void register_vo_delete(App *parent, GeneralOptions *genOpt, VoOptions *voOpt) {
    auto voDeleteOpt = new VoDeleteOptions();
    App *delete_ = parent->add_subcommand("delete", "Delete a new vo");
    delete_->add_option("vo-name", voDeleteOpt->vo_name, "Name of the vo to delete")->required();
    delete_->set_callback([genOpt, voOpt, voDeleteOpt]() {vo_delete(*genOpt, *voOpt, *voDeleteOpt);});
}

void register_vo(App *parent, GeneralOptions *genOpt) {
  auto voOpt = new VoOptions();
  App *vo = parent->add_subcommand("vo", "Manage SLATE vos");
  vo->require_subcommand();
    register_vo_create(vo, genOpt, voOpt);
    register_vo_list(vo, genOpt, voOpt);
    register_vo_delete(vo, genOpt, voOpt);
}

void cluster_list(GeneralOptions &genOpt, ClusterOptions &clustOpt, ClusterListOptions &clustListOpt) {
  json null;
  json response = genOpt.client.cluster_list(null);

  printResponse(genOpt, response, [](ostream& out, json& response) -> void{
    printClusterTable(cout, response["/items"_json_pointer]);
  });
}

void register_cluster_list(App *parent, GeneralOptions *genOpt, ClusterOptions *clustOpt) {
  auto clustListOpt = new ClusterListOptions();
  App *list = parent->add_subcommand("list", "Lists available clusters");
  list->set_callback([genOpt, clustOpt, clustListOpt]() {cluster_list(*genOpt, *clustOpt, *clustListOpt);});
}

void register_cluster(App *parent, GeneralOptions *genOpt) {
  auto clustOpt = new ClusterOptions();
  App *cluster = parent->add_subcommand("cluster", "Manage SLATE clusters");
  cluster->require_subcommand();
  register_cluster_list(cluster, genOpt, clustOpt);
}

function<string(const string&)> valueIn(const vector<string>& allowed) {
  return [allowed](const string& output) {
    if (find(allowed.begin(), allowed.end(), output) == allowed.end()) {
      string message = "value \"" + output + "\" not recognized. Must be one of [";
      for (unsigned int i = 0; i < allowed.size(); i++) {
        if (i !=0) message += ", ";
        message += allowed[i];
      }
      message += "]";
      return message;
    } else {
      return string("");
    }
  };
}

int main(int argc, char **argv) {
  auto genOpt = new GeneralOptions();
  
  App slate("SLATE command line interface");
  Option* output = slate.add_option("--output", genOpt->output, "Output format. Must be default or json.");
  Option* debug = slate.add_flag("--debug", genOpt->debug, "Prints extra info to debug the commandline.");
  output->group("General");
  output->check(valueIn({"default", "json"}));
  debug->group("General");
  slate.require_subcommand(); // 1 or more
  slate.fallthrough();

  register_app(&slate, genOpt);
  register_version(&slate, genOpt);
  register_vo(&slate, genOpt);
  register_cluster(&slate, genOpt);

  CLI11_PARSE(slate, argc, argv);

  return 0;
}
