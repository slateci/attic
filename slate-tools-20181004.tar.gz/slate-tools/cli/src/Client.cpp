#include "Util.h"
#include "Client.h"
#include "json.h"
#include <sys/stat.h>
#include <fstream>
#include <iostream>
#include <chrono>

using nlohmann::json;
using std::cout;
using std::endl;
using std::string;
using std::vector;

json call_command(const json input, const std::string command_name) {
  std::string commandResult = run_command("echo '" + input.dump() + "' | python3 /usr/lib/slate-service/lib/python/" + command_name + ".py");
  return json::parse(commandResult);
}

json kubectl_list_namespaces(string cluster) {
    std::string output = run_command("kubectl --kubeconfig /usr/lib/slate-service/etc/kubeconfig get namespaces --output=json --context " + cluster);
    return json::parse(output);
}

void kubectl_create_namespace(string cluster, string vo) {
    run_command("kubectl --kubeconfig /usr/lib/slate-service/etc/kubeconfig create namespace vo-" + vo + " --output=json --context " + cluster);
}

void kubectl_delete_namespace(string cluster, string vo) {
    run_command("kubectl --kubeconfig /usr/lib/slate-service/etc/kubeconfig delete namespace vo-" + vo + " --context " + cluster);
}

/*
 * TODO: implement namespace/vo sync
void Client::sync_namespaces() {
    json null;
    json clusters = cluster_list(null)["/items"_json_pointer];
    json vos = vo_list(null)["/items"_json_pointer];
    vector<string> cluster_names = extract_values(clusters, "/metadata/name"_json_pointer);
    vector<string> vo_names = extract_values(vos, "/metadata/name"_json_pointer);

    for (auto& cluster_name : cluster_names) {
        json namespaces = kubectl_list_namespaces(cluster_name)["/items"_json_pointer];
        vector<string> namespace_names = json_extract_values(namespaces, "/metadata/name"_json_pointer);
        vector<string> missing_vos = vo_names;
        for (auto& namespace_name : namespace_names) {
            if (string_starts_with(namespace_name, "vo-")) {
                // The namespace corresponds to the vo
                string vo_name = namespace_name.substr(3);

                // Find whether the vo is in the list
                auto index = std::find(vo_names.begin(), vo_names.end(), vo_name);
                if (index == vo_names.end()) {
                    // It's not in the list: delete the corresponding namespace

                }
            }
        }
    }
}
 */

json error_response(string message) {
    return {{"kind", "Error"}, {"message", message}};
}

json items_response(json items) {
    return {{"apiVersion", "v1alpha1"}, {"items", items}};
}

Client::Client(void) {
    struct stat info;
    string homedir = getenv("HOME");
    string helmdir = homedir + "/.helm";
    if (stat(helmdir.c_str(), &info) != 0) {
        string helmInitOutput = run_command("helm init --client-only");
        string helmRepoAddOutput = run_command("helm repo add slate https://raw.githubusercontent.com/slateci/slate-catalog/master/stable-repo/");
        string helmRepoDevAddOutput = run_command("helm repo add slate-dev https://raw.githubusercontent.com/slateci/slate-catalog/master/incubator-repo/");
    }
}

json Client::load_vo_list() {
    std::ifstream vo_list("/usr/lib/slate-service/etc/vo_list.yaml");
    if (vo_list) {
        json result;
        vo_list >> result;
        return result;
    } else {
        return json::array();
    }
}

void Client::save_vo_list(json vos) {
    std::ofstream vo_list("/usr/lib/slate-service/etc/vo_list.yaml");
    if (vo_list) {
        vo_list << vos.dump(4) << endl;
    } else {
        throw string("cannot update vo list");
    }
}

void Client::validate_vo(json vo) {
    // TODO: implement
}

json Client::vo_create(const json new_vo) {
    validate_vo(new_vo);

    // Make sure the vo does not already exist
    string new_vo_name = new_vo["/metadata/name"_json_pointer];
    json vos = load_vo_list();
    for (auto& vo : vos) {
        if (new_vo_name == vo["/metadata/name"_json_pointer]) {
            return error_response("vo " + new_vo_name + " already exists");
        }
    }

    // Add the vo and save the list
    vos.push_back(new_vo);
    try {
        save_vo_list(vos);
    } catch (string& message) {
        return error_response(message);
    }

    // Add the vo namespace from all clusters
    json null;
    json clusters = cluster_list(null)["/items"_json_pointer];
    vector<string> cluster_names = json_extract_values(clusters, "/metadata/name"_json_pointer);
    for (auto& cluster_name : cluster_names) {
        kubectl_create_namespace(cluster_name, new_vo_name);
    }

    return new_vo;
}

json Client::vo_list(const json input) {
  return items_response(load_vo_list());
}

json Client::vo_delete(const json target_vo) {
    validate_vo(target_vo);

    // Check the vo exists
    string target_vo_name = target_vo["/metadata/name"_json_pointer];
    json vos = load_vo_list();
    unsigned int n;
    for (n = 0; n < vos.size(); n++) {
        if (target_vo_name == vos[n]["/metadata/name"_json_pointer]) {
            break;
        }
    }
    if (n == vos.size()) {
        return error_response("vo " + target_vo_name + " does not exist");
    }

    // Delete the vo and save the new list
    vos.erase(n);
    try {
        save_vo_list(vos);
    } catch (string& message) {
        return error_response(message);
    }

    // Remove the vo namespace from all clusters
    json null;
    json clusters = cluster_list(null)["/items"_json_pointer];
    vector<string> cluster_names = json_extract_values(clusters, "/metadata/name"_json_pointer);
    for (auto& cluster_name : cluster_names) {
        kubectl_delete_namespace(cluster_name, target_vo_name);
    }

    return target_vo;
}
   
json Client::cluster_list(const json input) {
    std::string output = run_command("kubectl --kubeconfig /usr/lib/slate-service/etc/kubeconfig config get-contexts | awk '{print $2}'");

    std::stringstream ss(output);
    std::string line;
    json items = json::array();
    int n = 0;
    while(std::getline(ss, line, '\n')){
        if (n > 0) {
            string cluster_name = trim(line);
            json cluster = {{"apiVersion", "v1alpha1"}, {"kind", "Cluster"}, {"metadata", {{"name", cluster_name}}}};
            items.push_back(cluster);
        }
        n++;
    }

    json response;
    response["apiVersion"] = "v1alpha1";
    response["items"] = items;

    return response;
}

string helm_error_response(const vector<string> &stderr) {
    if (stderr.size() > 0 && string_starts_with(stderr[0], "Error: ")) {
        return stderr[0].substr(7);
    }

    return "";
}

json parse_helm_search_table(vector<string> lines, string catalog) {
    // Return empty table if no lines are present
    if (lines.size() == 0) {
        return items_response({});
    }

    // Find columns start and end
    vector<int> column_start;
    bool whitespace = true;
    for (unsigned int position = 0; position < lines[0].size(); position++) {
        if (std::isspace(lines[0][position])) {
            whitespace = true;
        } else {
            if (whitespace == true) {
                column_start.push_back(position);
                whitespace = false;
            }
        }
    }
    column_start.push_back(lines[0].size());

    json response = {};
    response["apiVersion"] = "v1alpha1";
    response["items"] = {};

    for (unsigned int n = 1; n < lines.size(); n++) {
        auto tokens = string_split_columns(lines[n], '\t');
        if (string_starts_with(tokens[0], catalog)) {
            json app = {{"apiVersion", "v1alpha1"},
                        {"kind", "Application"},
                        {"metadata", {{"name", tokens[0].substr(catalog.size())},
                                               {"version", tokens[1]},
                                               {"description", tokens[3]}}}};
            response["items"].push_back(app);
        }
    }

    return response;
}

json Client::app_search(const json request) {

    string catalog_name = "slate/";
    if (request.find("developmentVersion")!=request.end()) {
        catalog_name = "slate-dev/";
    }

    string command = "export KUBECONFIG=/usr/lib/slate-service/etc/kubeconfig && helm search >&1";
    vector<string> output_lines = string_split_lines(run_command(command));

    if (helm_error_response(output_lines) != "") {
        return error_response(helm_error_response(output_lines));
    }

    return parse_helm_search_table(output_lines, catalog_name);
}

json Client::app_conf(const json input) {
    string app_name = input["/application"_json_pointer];
    string configuration_body;
    if (input.find("developmentVersion")==input.end()) {
        configuration_body = run_command("helm inspect values slate/" + app_name + " 2>&1");
    } else {
        configuration_body = run_command("helm inspect values slate-dev/" + app_name + " 2>&1");
    }
    vector<string> output_lines = string_split_lines(configuration_body);

    // Check for errors
    if (output_lines.size() > 0 && string_starts_with(output_lines[0], "Error: ")) {
        return error_response("Couldn't find or download application \"" + app_name + "\"");
    }

    json response = {{"apiVersion", "v1alpha1"},
                     {"kind", "Configuration"},
                     {"metadata",
                                    {{"name", app_name}}},
                     {"spec",
                                    {{"body", configuration_body}}}};
    return response;
}

json parse_helm_list_table(vector<string> lines) {
    // Return empty table if no lines are present
    if (lines.size() == 0) {
        return items_response({});
    }

    // Find columns start and end
    vector<int> column_start;
    bool whitespace = true;
    for (unsigned int position = 0; position < lines[0].size(); position++) {
        if (std::isspace(lines[0][position])) {
            whitespace = true;
        } else {
            if (whitespace == true) {
                column_start.push_back(position);
                whitespace = false;
            }
        }
    }
    column_start.push_back(lines[0].size());

    json response = {};
    response["apiVersion"] = "v1alpha1";
    response["items"] = {};

    for (unsigned int n = 1; n < lines.size(); n++) {
        auto tokens = string_split_columns(lines[n], '\t');
        if (string_starts_with(tokens[5], "vo-")) {
            json app = {{"apiVersion", "v1alpha1"},
                        {"kind", "ApplicationInstance"},
                        {"metadata", {{"name", tokens[0]},
                                             {"revision", tokens[1]},
                                             {"updated", tokens[2]},
                                             {"application", tokens[4]},
                                             {"vo", tokens[5].substr(3)}}},
                        {"status", {{"phase", tokens[3]}}}};
            response["items"].push_back(app);
        }
    }

    return response;
}

json Client::app_install(const json request) {

    if (request.find("application") == request.end() || request["application"] == "") {
        return error_response("Missing application option");
    }

    if (request.find("cluster") == request.end() || request["cluster"] == "") {
        return error_response("Missing cluster option");
    }

    if (request.find("vo") == request.end() || request["vo"] == "") {
        return error_response("Missing vo option");
    }

    string catalog_name = "slate/";
    if (request.find("developmentVersion")!=request.end()) {
        catalog_name = "slate-dev/";
    }

    std::chrono::milliseconds timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
    string application_name = request["application"];
    string cluster_name = request["cluster"];
    string vo_name = request["vo"];
    string application_instance_name = application_name + "-" + std::to_string(timestamp.count());
    string command = "export KUBECONFIG=/usr/lib/slate-service/etc/kubeconfig && helm install " + catalog_name + application_name
                     + " --kube-context " + cluster_name
                     + " --name " + application_instance_name
                     + " --namespace vo-" + vo_name;
    if (request.find("configuration") != request.end()) {
        string conf_filename = "/tmp/app-install-" + application_instance_name + ".yaml";
        std::ofstream conf_file(conf_filename);
        if (conf_file) {
            string configuration = request["configuration"];
            conf_file << configuration;
        } else {
            return error_response("could not preapre configuration file");
        }
        command += " --values " + conf_filename;
    }
    command += " 2>&1";
    string output = run_command(command);
    vector<string> output_lines = string_split_lines(output);

    // Check for errors
    if (output_lines.size() > 0 && string_starts_with(output_lines[0], "Error: failed to download")) {
        return error_response("Couldn't find or download application \"" + application_name + "\"");
    }

    if (helm_error_response(output_lines) != "") {
        return error_response(helm_error_response(output_lines));
    }

    if ((output_lines.size() > 0) && string_starts_with(output_lines[0], "NAME: ")) {
        json app = {{"apiVersion", "v1alpha1"},
                    {"kind", "ApplicationInstance"},
                    {"metadata", {{"name", application_name},
                                           {"revision", "1"},
                                           {"updated", "TODO"},
                                           {"application", application_name},
                                           {"vo", vo_name}}},
                    {"status", {{"phase", "DEPLOYED"}}}};
        return app;
    }

    return error_response("Unexpected response.\nstdout/stderr\n" + output);
}

json Client::app_list(const json input) {
    string command = "export KUBECONFIG=/usr/lib/slate-service/etc/kubeconfig && helm list --kube-context ";
    command += input["cluster"];
    command += " --namespace vo-";
    command += input["vo"];
    command += " 2>&1";
    vector<string> output_lines = string_split_lines(run_command(command));

    if (helm_error_response(output_lines) != "") {
        return error_response(helm_error_response(output_lines));
    }

    return parse_helm_list_table(output_lines);
}

json Client::app_delete(const json input) {
  return call_command(input, "slate_app_delete");
}
