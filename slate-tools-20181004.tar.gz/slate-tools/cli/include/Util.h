#ifndef _UTIL_H_
#define _UTIL_H_

#include "json.h"
#include <sys/stat.h>
#include <fstream>
#include <iostream>

using nlohmann::json;
using std::cout;
using std::endl;
using std::string;
using std::vector;

string run_command(const string &command) {
    std::array<char, 128> buffer;
    std::string result;
    std::shared_ptr<FILE> pipe(popen(command.c_str(), "r"), pclose);
    if (!pipe) throw std::runtime_error("popen() failed!");
    while (!feof(pipe.get())) {
        if (fgets(buffer.data(), 128, pipe.get()) != nullptr)
            result += buffer.data();
    }
    return result;
}

inline std::string trim(const std::string &s) {
    auto wsfront = std::find_if_not(s.begin(),s.end(),[](int c){return std::isspace(c);});
    auto wsback = std::find_if_not(s.rbegin(),s.rend(),[](int c){return std::isspace(c);}).base();
    return (wsback <= wsfront ? std::string() : std::string(wsfront, wsback));
}

inline bool string_starts_with(std::string a_string, std::string match_string) {
    return a_string.find(match_string) == 0;
}

vector<string> string_split_lines(const string &text) {
    std::stringstream ss(text);
    vector<string> lines;
    string line;
    while(std::getline(ss, line)){
        lines.push_back(line);
    }

    return lines;
}

vector<string> string_split_columns(const string &line, const vector<int> &column_start) {
    vector<string> tokens;
    for (unsigned int col = 0; col < column_start.size() -1; col++) {
        tokens.push_back(trim(line.substr(column_start[col], column_start[col+1])));
    }
    return tokens;
}

vector<string> string_split_columns(const string &line, const char &delim) {
    std::stringstream ss(line);
    vector<string> tokens;
    std::string item;
    while (std::getline(ss, item, delim)) {
        tokens.push_back(trim(item));
    }
    return tokens;
}

bool vector_contains(vector<string> v, string x) {
    return std::find(v.begin(), v.end(), x) != v.end();
}

vector<string> json_extract_values(json array, json::json_pointer pointer) {
    vector<string> values;
    for (auto& element : array) {
        values.push_back(element[pointer]);
    }
    return values;
}

#endif
