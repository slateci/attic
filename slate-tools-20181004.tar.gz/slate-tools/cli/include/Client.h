#ifndef _CLIENT_H_
#define _CLIENT_H_

#include "json.h"

using nlohmann::json;

class Client
{
public:
    Client();
    json vo_create(const json);
    json vo_list(const json);
    json vo_delete(const json);
    json cluster_list(const json);
    json app_search(const json);
    json app_conf(const json);
    json app_install(const json);
    json app_list(const json);
    json app_delete(const json);
private:
    json load_vo_list();
    void save_vo_list(json vos);
    void validate_vo(json vo);
    void sync_namespaces();
};
#endif
