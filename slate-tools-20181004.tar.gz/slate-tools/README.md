# slate-tools
The SLATE command-line and service

# Build instruction (for SLATE developers)

Clone the repository on a machine where bash, cmake and gcc are installed in the path.

```
> git clone https://github.com/slateci/slate-tools.git
```

Run the build script

```
> ./build.sh
```

In the build/target directory you'll find the output of the build.

```
build/target
   |
   - slate (the command line executable)
   |
   - slate-service (the slate service application directory)
```

# Install instruction (for SLATE developers)

Copy the the slate-service directory in /usr/lib/slate-service:

```
> sudo cp -r build/target/slate-service /usr/lib
```

and place the kubernetes configuration file in the etc directory:

```
> cp kube/.config /usr/lib/slate-service/etc/kubeconfig 
```

Place the slate executable in a directory accessible in the path:
```
> sudo cp build/target/slate /usr/local/bin
```
